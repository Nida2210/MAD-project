package com.projectx.spa.interfaces;

public interface Settable {

    void setId(String id);

}